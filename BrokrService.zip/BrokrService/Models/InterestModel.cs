﻿namespace BrokrService.Models
{
    public class InterestModel
    {
    }
}
